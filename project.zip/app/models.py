# models.py
from django.db import models
from django.utils import timezone


class Category(models.Model):
    name = models.CharField(
        max_length=255,
        unique=True
    )

    sport_type = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        help_text="Cricket, Football, Basketball, etc."
    )

    order = models.PositiveIntegerField(
        default=0,
        help_text="Lower number = higher position"
    )

    # Changed from SlugField to CharField to allow '/'
    slug = models.CharField(
        max_length=255,
        unique=True,
        blank=True,
        help_text="URL path for the category, e.g. movie/hind-dubbed"
    )

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ["order", "name"]

    def __str__(self):
        if self.sport_type:
            return f"{self.name} ({self.sport_type})"
        return self.name

    def save(self, *args, **kwargs):
        # Slug is manually added, no auto-generation
        super().save(*args, **kwargs)



    
class Country(models.Model):
    """Model to represent course categories."""
    name = models.CharField(max_length=255, unique=True)

    class Meta:
        verbose_name_plural = "Countries"

    def __str__(self):
        return self.name

class dash_player(models.Model):
    name = models.CharField(max_length=100, unique=True)
    title = models.CharField(max_length=100)
    top_control_title = models.CharField()
    dash_url = models.URLField()
    dash_clear_key = models.JSONField(blank=True, null=True)  # ✅ JSONField
     

    def __str__(self):
        return self.name



class proxy_player(models.Model):
    name = models.CharField(max_length=100, unique=True, help_text="The stream name used in play.php?stream=")
    title = models.CharField(max_length=100)
    top_control_title = models.CharField()

    def __str__(self):
        return self.name


class channel(models.Model):
    name = models.CharField(max_length=100, unique=True)
    image = models.ImageField(
        upload_to='courses/images/', 
        blank=True, 
        null=True
    )
    dash_players = models.ManyToManyField('dash_player', blank=True)
    proxy_players = models.ManyToManyField('proxy_player', blank=True)
    categories = models.ManyToManyField('Category', blank=True)
    countries = models.ManyToManyField('Country', blank=True)

    order = models.PositiveIntegerField(default=0, help_text="Sort order of the channel")  # ← Added order field

    class Meta:
        ordering = ['order', 'name']  # default ordering by 'order', then by 'name'

    def __str__(self):
        return self.name



class Event(models.Model):
    name = models.CharField(
        max_length=100,
        help_text="Event or League name (e.g. Big Bash League)"
    )

    match_label = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        help_text="25th Match, Final, 1st ODI etc."
    )

    is_league_event = models.BooleanField(
        default=False,
        help_text="Enable if this event uses only league image (no teams)"
    )

    team_a_name = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )

    team_b_name = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )

    image_primary = models.ImageField(
        upload_to='events/images/',
        blank=True,
        null=True,
        help_text="League logo OR Team A logo"
    )

    image_secondary = models.ImageField(
        upload_to='events/images/',
        blank=True,
        null=True,
        help_text="Team B logo"
    )

    start_time = models.DateTimeField(
        help_text="Event start time (UTC)"
    )

    end_time = models.DateTimeField(
        blank=True,
        null=True
    )

    dash_players = models.ManyToManyField('dash_player', blank=True)
    proxy_players = models.ManyToManyField('proxy_player', blank=True)
    categories = models.ManyToManyField('Category', blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    # =========================
    # ORDER FIELD
    # =========================
    order = models.PositiveIntegerField(default=0, help_text="Sort order of the event")  # ← added

    # =========================
    # STATUS HELPERS
    # =========================
    def is_live(self):
        now = timezone.now()
        if self.end_time:
            return self.start_time <= now <= self.end_time
        return self.start_time <= now

    def get_status(self):
        today = timezone.now().date()
        event_date = self.start_time.date()

        if self.is_live():
            return "LIVE"
        elif event_date == today:
            return "TODAY"
        elif event_date == today + timezone.timedelta(days=1):
            return "TOMORROW"
        return "UPCOMING"

    @property
    def status(self):
        return self.get_status()

    def __str__(self):
        if self.is_league_event:
            return f"{self.name} ({self.match_label})" if self.match_label else self.name
        return f"{self.team_a_name} vs {self.team_b_name}"

    class Meta:
        ordering = ['order', 'start_time']  # ← default ordering by 'order' then by start_time
