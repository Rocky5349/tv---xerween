from django.urls import path
from . import views


urlpatterns = [
     path('', views.index, name='index'),
     path('event/', views.event_list, name='event_list'),
     path("event/filter/", views.event_filter_ajax, name="event_filter_ajax"),
     path("api/event/<int:event_id>/streams/", views.event_streams_api),
     path('live/', views.channel_list, name='channel_list'),
     path("api/channel/<int:channel_id>/streams/", views.channel_streams_api),
     path('movie/', views.movie_list, name='movie_list'),
     path('tv-show/', views.tv_show_list, name='tv_show_list'),
     path('animation/', views.animation_movie_list, name='animation_movie_list'),
     path('dash/<str:name>/', views.dash_player_view, name='dash_player_view'),
     path('play/<str:channel_name>/', views.play_channel, name='play_channel'),
     path('play/<str:channel_name>/token/', views.get_fresh_token, name='get_fresh_token'),
     path("courses/search/", views.search_results, name="search_results"),
     path("search-suggestions/", views.search_suggestions, name="search_suggestions"),
     # ⚠️ MUST BE LAST
     path("<path:slug>/", views.channel_by_category_slug, name="category_by_slug"),
     

]