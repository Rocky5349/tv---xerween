from django.shortcuts import render, get_object_or_404
import re
import requests
from django.shortcuts import render
from .models import channel, dash_player, proxy_player, Category, Event
from django.http import HttpResponse
from django.http import JsonResponse
from django.views.decorators.http import require_GET
from django.utils import timezone

from django.db.models import Q
from django.urls import reverse




# =========================
# INDEX PAGE
# =========================
def index(request):
    return render(request, "index.html")



STATUS_LIST = ["ALL", "LIVE", "TODAY", "TOMORROW", "UPCOMING"]


# =========================
# EVENT PAGE
# =========================
@require_GET
def event_list(request):
    status = request.GET.get("status", "ALL")
    category_event_map = _get_events_grouped_by_category(status)

    return render(request, "events.html", {
        "category_event_map": category_event_map,
        "active_status": status,
        "status_list": STATUS_LIST,
    })


# =========================
# EVENT FILTER (AJAX)
# =========================
@require_GET
def event_filter_ajax(request):
    status = request.GET.get("status", "ALL")
    category_event_map = _get_events_grouped_by_category(status)

    html = render(
        request,
        "partials/event_category_blocks.html",
        {"category_event_map": category_event_map}
    ).content.decode("utf-8")

    return JsonResponse({"html": html})


# =========================
# CORE QUERY LOGIC
# =========================
def _get_events_grouped_by_category(status):
    now = timezone.now()
    today = now.date()
    tomorrow = today + timezone.timedelta(days=1)

    # Start with all events
    base_qs = Event.objects.prefetch_related(
        "categories", "dash_players", "proxy_players").distinct()

    # -------- STATUS FILTERING --------
    if status == "LIVE":
        # Events already started and not ended
        base_qs = base_qs.filter(
            Q(start_time__lte=now) &
            (Q(end_time__isnull=True) | Q(end_time__gte=now))
        )

    elif status == "TODAY":
        # Events later today (exclude LIVE)
        base_qs = base_qs.filter(
            start_time__date=today,
            start_time__gt=now
        )

    elif status == "TOMORROW":
        # Events starting tomorrow
        base_qs = base_qs.filter(
            start_time__date=tomorrow
        )

    elif status == "UPCOMING":
        # Events after tomorrow
        base_qs = base_qs.filter(
            start_time__date__gt=tomorrow
        )

    # -------- CATEGORY GROUPING --------
    categories = Category.objects.order_by("order")
    result = []

    for category in categories:
        cat_events = (
            base_qs
            .filter(categories=category)
            .order_by("order", "start_time")
        )

        if cat_events.exists():
            result.append({
                "category": category,
                "events": cat_events
            })

    return result



# =========================
# EVENT STREAM API
# =========================
@require_GET
def event_streams_api(request, event_id):
    event = get_object_or_404(Event, pk=event_id)

    return JsonResponse({
        "dash": [
            {"name": d.name, "title": d.title}
            for d in event.dash_players.all()
        ],
        "proxy": [
            {"name": p.name, "title": p.title}
            for p in event.proxy_players.all()
        ]
    })


# =========================
# LIVE PAGE (INITIAL LOAD)
# =========================
@require_GET
def channel_list(request):
    categories = Category.objects.filter(
        channel__isnull=False
    ).distinct().order_by("order")

    channels = (
        channel.objects
        .prefetch_related("categories", "dash_players", "proxy_players")
        .order_by("order")
    )

    return render(request, "live.html", {
        "categories": categories,
        "channels": channels,
        "active_category": None
    })

from django.db.models import Q

@require_GET
def search_results(request):
    query = request.GET.get("q", "").strip()
    results = channel.objects.none()

    if query:
        results = (
            channel.objects
            .filter(
                Q(name__icontains=query) |
                Q(categories__name__icontains=query) |
                Q(countries__name__icontains=query)
            )
            .prefetch_related("categories", "dash_players", "proxy_players")
            .distinct()
        )

    return render(request, "search_results.html", {
        "query": query,
        "results": results
    })

@require_GET
def search_suggestions(request):
    query = request.GET.get("q", "").strip()

    if not query:
        return JsonResponse([], safe=False)

    channels = channel.objects.filter(
        name__icontains=query
    ).order_by("name")[:8]

    results = list(channels.values("id", "name"))

    return JsonResponse(results, safe=False)

# =========================
# CATEGORY SLUG (AJAX + NORMAL)
# =========================
@require_GET
def channel_by_category_slug(request, slug):

    # --------- ALL CATEGORY ---------
    if slug == "all":
        categories = Category.objects.filter(
            channel__isnull=False
        ).distinct().order_by("order")

        channels = (
            channel.objects
            .prefetch_related("categories", "dash_players", "proxy_players")
            .order_by("order")
        )

        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            html = render(
                request,
                "partials/channel_cards.html",
                {"channels": channels}
            ).content.decode("utf-8")

            return JsonResponse({"html": html})

        return render(request, "live.html", {
            "categories": categories,
            "channels": channels,
            "active_category": None
        })


    # -------- EXISTING CATEGORY LOGIC --------
    category = get_object_or_404(Category, slug=slug)

    categories = Category.objects.filter(
        channel__isnull=False
    ).distinct().order_by("order")

    channels = (
        channel.objects
        .filter(categories=category)
        .prefetch_related("categories", "dash_players", "proxy_players")
        .order_by("order")
    )

    if request.headers.get("x-requested-with") == "XMLHttpRequest":
        html = render(
            request,
            "partials/channel_cards.html",
            {"channels": channels}
        ).content.decode("utf-8")

        return JsonResponse({"html": html})

    return render(request, "live.html", {
        "categories": categories,
        "channels": channels,
        "active_category": category
    })



# =========================
# CHANNEL STREAMS API
# =========================
@require_GET
def channel_streams_api(request, channel_id):
    ch = get_object_or_404(channel, pk=channel_id)

    dash_list = [
        {"name": d.name, "title": d.title}
        for d in ch.dash_players.all()
    ]

    proxy_list = [
        {"name": p.name, "title": p.title}
        for p in ch.proxy_players.all()
    ]

    return JsonResponse({
        "dash": dash_list,
        "proxy": proxy_list
    })



def movie_list(request):
    return render(request, "movies.html")

def tv_show_list(request):
    return render(request, "tv-shows.html")

def animation_movie_list(request):
    return render(request, "animation.html")



def dash_player_view(request, name):
    """
    Render a player page for a given DashPlayer instance.
    """
    player = get_object_or_404(dash_player, name=name)

    context = {
        "dash_url": player.dash_url,
        "dash_clear_key": player.dash_clear_key or {},  # already a dict
        "title": player.title,
        "top_control_title": player.top_control_title,
    }
    return render(request, "dash_player.html", context)


def get_token(stream_name):
    """Fetch token from IPTV source using the stream name"""
    url = f"http://iptvidn.com/play.php?stream={stream_name}"
    headers = {"Referer": "http://iptvidn.com/"}
    response = requests.get(url, headers=headers, timeout=10)
    response.raise_for_status()

    html = response.text
    match = re.search(r"token=([A-Za-z0-9\-_]+)", html)
    if match:
        return match.group(1)
    return None

def play_channel(request, channel_name):
    """
    Render HTML template with the live .m3u8 URL
    and send the player controls HTML to the template
    """
    try:
        # Get the channel from your model
        channel = get_object_or_404(proxy_player, name=channel_name)

        # Fetch token using the channel name
        token = get_token(channel.name)
        if not token:
            return render(request, "error.html", {"message": "Token not found"})

        # Construct the m3u8 URL
        m3u8_url = f"http://103.89.248.26:8082/{channel.name}/index.fmp4.m3u8?token={token}"


        return render(request, "proxy_player.html", {
            "channel": channel.name,
            "m3u8": m3u8_url,
        })

    except requests.RequestException as e:
        return render(request, "error.html", {"message": str(e)})

def get_fresh_token(request, channel_name):
    """Return fresh m3u8 URL for a channel without rendering full template"""
    channel = get_object_or_404(proxy_player, name=channel_name)
    token = get_token(channel.name)
    if not token:
        return HttpResponse("Token not found", status=404)
    m3u8_url = f"http://103.89.248.26:8082/{channel.name}/index.fmp4.m3u8?token={token}"
    return HttpResponse(m3u8_url)

