
window.initShakaPlayer = async function() {
    const video = document.getElementById('video');
    const player = new shaka.Player(video);
    const playerContainer = document.getElementById('player-container');
    const centerPlayBtn = document.getElementById("center-play-btn");
    const smallPlayBtn = document.getElementById("small-play-btn");
    const seekbar = document.getElementById("seekbar");
    const volume = document.getElementById("volume");
    const fullscreenBtn = document.getElementById("fullscreen-btn");
    const resolutionBtn = document.querySelector(".resolution-button");
    const resolutionDropdown = resolutionBtn.querySelector(".resolution-dropdown");
    const closeBtn = document.getElementById("close-btn");
    const muteBtn = document.getElementById("mute-btn");
    const lockBtn = document.getElementById("lock-btn");
    const controls = document.getElementById("controls");
    const topControls = document.getElementById("top-control");
    const goLiveBtn = document.getElementById("goLiveBtn");
    const forwardBtn = document.getElementById("forward10");
    const backwardBtn = document.getElementById("backward10");

    if (!video) {
        console.error("Player HTML not loaded yet!");
        return;
    }

    // --- Destroy previous player instance (if switching channels) ---
    if (window._shakaPlayerInstance) {
        try { await window._shakaPlayerInstance.destroy(); } catch(e) {}
    }

    
    window._shakaPlayerInstance = player;

    // --- Now safely read Django values ---
    const streamUrl = window.playerConfig.streamUrl;
    const clearKeys = window.playerConfig.clearKey;

    async function loadStream(url) {
        try {
            if (url.includes('.m3u8')) {
                player.configure({ streaming: { lowLatencyMode: true } });
                await player.load(url);
            } else if (url.includes('.mpd')) {
                player.configure({
                    drm: {
                        clearKeys: clearKeys
                    }
                });
                await player.load(url);
            } else {
                throw new Error('Unsupported stream type');
            }
            console.log("Stream loaded:", url);
        } catch (error) {
            console.error('Error loading stream:', error);
        }
    }

    // Initial load
    await loadStream(streamUrl);

    // Auto-refresh every 2.5 hours
    setInterval(async () => {
        try {
            // Only refresh if current stream is m3u8
            if (streamUrl.includes('.m3u8')) {
                const response = await fetch(window.playerConfig.freshTokenUrl);
                if (!response.ok) throw new Error('Failed to get fresh token');

                const newUrl = await response.text();
                console.log("Refreshing stream with new token:", newUrl);

                // Reload stream with fresh token
                await loadStream(newUrl);
            } else {
                console.log("Auto-refresh skipped: not an m3u8 stream");
            }
        } catch (error) {
            console.error("Error refreshing token:", error);
        }
    }, 2.5 * 60 * 60 * 1000); // 2.5 hours


    // ... 🔽 keep the rest of your player logic unchanged (controls, seekbar, resolution, etc.)



    // --- Go Live Button (Transparent, Red/Orange Dot, White Text) ---
    const LIVE_EDGE_TOLERANCE = 2; // seconds tolerance near live edge

    function updateGoLiveButton() {
        const range = player.seekRange();
        const liveEdge = range.end;
        const current = video.currentTime;
        const behind = liveEdge - current;

        if (behind > LIVE_EDGE_TOLERANCE) {
            // 🟠 Behind live
            goLiveBtn.classList.add("behind");
        } else {
            // 🔴 At live edge
            goLiveBtn.classList.remove("behind");
        }

    }

    function jumpToLive() {
    if (!player.isLive()) return;
    const range = player.seekRange();
    const liveEdge = range.end;
    video.currentTime = liveEdge - 0.5;
    player.play();
    updateGoLiveButton();
    // Add  border color on click
        goLiveBtn.style.border = "2px solid blue";

        // Optional: remove border after short delay
        setTimeout(() => {
            goLiveBtn.style.border = ""; // or "none"
        }, 200);

}

    goLiveBtn.addEventListener("click", jumpToLive);
    setInterval(updateGoLiveButton, 1000);
    video.addEventListener("timeupdate", updateGoLiveButton);
    video.addEventListener("seeking", updateGoLiveButton);



   let controlsLocked = false;
    lockBtn.onclick = () => {
        controlsLocked = !controlsLocked;
        const allControls = [topControls, forwardBtn, backwardBtn, centerPlayBtn, goLiveBtn, smallPlayBtn, muteBtn, volume, fullscreenBtn, resolutionBtn, closeBtn, seekbar];
        if(controlsLocked){
            lockBtn.textContent="lock";
            allControls.forEach(el=>{ el.style.pointerEvents="none"; el.style.opacity=0; });
             // Add smooth transition for background
             controls.style.backgroundColor = "rgba(0, 0, 0, 0)";
        } else {
            lockBtn.textContent="lock_open";
            allControls.forEach(el=>{ el.style.pointerEvents="auto"; el.style.opacity=1; });
            controls.style.backgroundColor = "rgba(0, 0, 0, 0.498)"; // or set your default color
        }

        // Add  border color on click
        lockBtn.style.border = "2px solid blue";

        // Optional: remove border after short delay
        setTimeout(() => {
            lockBtn.style.border = ""; // or "none"
        }, 200);
    };  

    
    // --- Play/Pause ---
    const togglePlay = () => { if(!controlsLocked) video.paused ? video.play() : video.pause(); };
    centerPlayBtn.onclick = togglePlay;
    smallPlayBtn.onclick = togglePlay;
    
    const updatePlayButtons = () => {
        centerPlayBtn.setAttribute("icon", video.paused ? "play" : "pause");
        
        smallPlayBtn.textContent = video.paused ? "play_arrow" : "pause";
    };
    video.onplay = () => {
    updatePlayButtons();
    requestWakeLock(); // keep screen awake
        centerPlayBtn.style.border = "2px solid blue";
                setTimeout(() => {
                    centerPlayBtn.style.border = ""; // or "none"
                }, 100);
    };

    video.onpause = () => {
        updatePlayButtons();
        releaseWakeLock(); // allow sleep again
        centerPlayBtn.style.border = "2px solid blue";
                setTimeout(() => {
                    centerPlayBtn.style.border = ""; // or "none"
                }, 100);
    };



    // --- Volume/Mute ---
    let lastVolume = video.volume;
    const updateVolumeVisual = () => {
        let level = video.muted ? 0 : video.volume;
        volume.value = level;
        volume.style.background = `linear-gradient(to right, rgb(255,255,255) 0%, rgb(255,255,255) ${level*100}%, rgba(255,255,255,0.54) ${level*100}%, rgba(255,255,255,0.54) 100%)`;
    };
    updateVolumeVisual();

    // 🔧 Add this check right after updating visuals
    if (video.muted || video.volume === 0) {
        muteBtn.textContent = "volume_off";
    } else {
        muteBtn.textContent = "volume_up";
    }

    muteBtn.onclick = () => {
        if (!controlsLocked) {
            if (video.muted) {
                video.muted = false;
                video.volume = lastVolume || 1;
                muteBtn.textContent = "volume_up";
            } else {
                video.muted = true;
                lastVolume = video.volume;
                video.volume = 0;
                muteBtn.textContent = "volume_off";
            }
            muteBtn.style.border = "2px solid blue";
            setTimeout(() => {
                muteBtn.style.border = ""; // or "none"
            }, 200);

            updateVolumeVisual();
        }
    };

    volume.addEventListener('input', () => {
        if (!controlsLocked) {
            video.volume = volume.value;
            if (video.volume == 0) {
                video.muted = true;
                muteBtn.textContent = "volume_off";
            } else {
                video.muted = false;
                muteBtn.textContent = "volume_up";
                lastVolume = video.volume;
            }
            updateVolumeVisual();
        }
    });

    
    // Close button click (hide overlay and stop video completely)
    closeBtn.onclick = async () => {
        if (!controlsLocked) {
            try {
                await player.unload();
            } catch (e) {
                console.warn("Error unloading player:", e);
            }

            // 🔵 Border flash first
            closeBtn.style.border = "2px solid blue";

            // ⏱ Wait a frame or two before continuing
            setTimeout(async () => {
                closeBtn.style.border = "";

                video.pause();
                video.currentTime = 0;
                seekbar.value = 0;
                seekbar.style.background = `
                    linear-gradient(
                        to right,
                        white 0%,
                        white 0%,
                        rgba(0, 0, 0, 0.498) 0%,
                        rgba(0, 0, 0, 0.498) 100%,
                        rgba(255,255,255,0.3) 100%
                    )
                `;
                centerPlayBtn.setAttribute("icon", "play");
                centerPlayBtn.style.opacity = 1;
                smallPlayBtn.textContent = "play_arrow";

                if (thumbJumpTimer) clearInterval(thumbJumpTimer);

                playerContainer.classList.add("hidden");

                // 🔽 Exit fullscreen AFTER visual feedback
                if (document.fullscreenElement) {
                    await document.exitFullscreen();
                    fullscreenBtn.textContent = "fullscreen";

                    if (screen.orientation && screen.orientation.unlock) {
                        screen.orientation.unlock();
                    }
                }

                const allControls = [
                    centerPlayBtn, smallPlayBtn, muteBtn, volume,
                    fullscreenBtn, resolutionBtn, closeBtn, seekbar, lockBtn, controls
                ];
                allControls.forEach(el => {
                    el.style.opacity = 0;
                    el.style.pointerEvents = "none";
                });

            }, 150); // 👈 Small delay before exiting fullscreen
        }
    };


    



    // --- Fullscreen ---
    // --- Fullscreen Toggle Button ---
    fullscreenBtn.onclick = async () => {
        if (!controlsLocked) {
            // 🔵 Border flash first
            fullscreenBtn.style.border = "2px solid blue";

            // ⏱ Wait a short moment before toggling fullscreen
            setTimeout(async () => {
                fullscreenBtn.style.border = "";

                try {
                    if (!document.fullscreenElement) {
                        // ENTER fullscreen
                        await playerContainer.requestFullscreen();
                        fullscreenBtn.textContent = "fullscreen_exit";

                        // Lock orientation to landscape (optional)
                        if (screen.orientation && screen.orientation.lock) {
                            try {
                                await screen.orientation.lock("landscape");
                            } catch (e) {
                                console.warn("Orientation lock failed:", e);
                            }
                        }
                    } else {
                        // EXIT fullscreen
                        await document.exitFullscreen();
                        fullscreenBtn.textContent = "fullscreen";

                        // Unlock screen orientation (optional)
                        if (screen.orientation && screen.orientation.unlock) {
                            screen.orientation.unlock();
                        }
                    }
                } catch (e) {
                    console.warn("Fullscreen toggle failed:", e);
                }

            }, 150); // 👈 Slight delay ensures border shows before fullscreen repaint
        }
    };

    // --- Sync button text with fullscreen state ---
    document.addEventListener("fullscreenchange", () => {
        if (!document.fullscreenElement) {
            fullscreenBtn.textContent = "fullscreen";
        } else {
            fullscreenBtn.textContent = "fullscreen_exit";
        }
    });




    // --- Dynamic Segment-Based Live Seekbar (Smooth Thumb + Scrubbing + Snap) ---
    let segmentDur = 3; // Default fallback
    let lastDetectedDur = 0;
    let isSeeking = false;
    let lastUpdateTime = 0;
    let thumbJumpTimer = null;
    let isScrubbing = false;

    // --- Detect segment duration dynamically ---
    function detectSegmentDurationDynamic() {
    try {
        const manifest = player.getManifest();
        const periods = manifest?.periods || [];
        if (!periods.length) return;

        const videoVariant = periods[0].variants.find(v => v.video);
        const stream = videoVariant?.video?.getSegmentIndex();
        if (!stream) return;

        const currentTime = video.currentTime;
        const ref = stream.find(currentTime);
        const seg = ref || stream.get(0);

        if (seg?.d && seg?.timescale) {
        const newDur = seg.d / seg.timescale;
        if (Math.abs(newDur - lastDetectedDur) > 0.001) {
            segmentDur = newDur;
            lastDetectedDur = newDur;
            console.log(`🔄 Segment duration updated: ${segmentDur.toFixed(2)}s`);
        }
        }
    } catch (err) {
        // fallback remains
    }
    }


    function animateThumbSmooth() {
    if (!player.isLive() || isSeeking || isScrubbing) return;

    const range = player.seekRange();
    const liveStart = range.start;
    const liveEnd = range.end;

    const currentTime = video.currentTime;
    const snappedTime = Math.floor(currentTime / segmentDur) * segmentDur;
    const nextSnap = snappedTime + segmentDur;

    const startPercent = ((snappedTime - liveStart) / (liveEnd - liveStart)) * 100;
    const endPercent = ((nextSnap - liveStart) / (liveEnd - liveStart)) * 100;

    
    seekbar.animate(
        [
        { value: `${startPercent}%` },
        { value: `${endPercent}%` }
        ],
        {
        duration: segmentDur * 1000,
        easing: "linear",
        fill: "forwards"
        }
    );


    seekbar.style.background = `
        linear-gradient(
        to right,
        white 0%,
        white ${startPercent}%,
        rgba(255,255,255,0.5) ${startPercent}%,
        rgba(255,255,255,0.5) ${endPercent}%,
        rgba(0, 0, 0, 0.498) ${endPercent}%,
        rgba(0, 0, 0, 0.498) 100%
        )
    `;
    }

    // --- Live seekbar updater ---
    function updateLiveSeekbar() {
    if (!player.isLive() || isSeeking || isScrubbing) return;

    const now = performance.now();
    if (now - lastUpdateTime > 500) { // faster updates
        detectSegmentDurationDynamic();
        lastUpdateTime = now;
    }

    const range = player.seekRange();
    const liveStart = range.start;
    const liveEnd = range.end;

    const snappedTime = Math.floor(video.currentTime / segmentDur) * segmentDur;
    const playedPercent = ((snappedTime - liveStart) / (liveEnd - liveStart)) * 100;

    let bufferedEnd = 0;
    if (video.buffered.length > 0) bufferedEnd = video.buffered.end(video.buffered.length - 1);
    const bufferPercent = ((bufferedEnd - liveStart) / (liveEnd - liveStart)) * 100;

    seekbar.value = playedPercent;
    seekbar.style.background = `
        linear-gradient(
        to right,
        white 0%,
        white ${playedPercent}%,
        rgba(255,255,255,0.5) ${playedPercent}%,
        rgba(255,255,255,0.5) ${bufferPercent}%,
        rgba(0, 0, 0, 0.498) ${bufferPercent}%,
        rgba(0, 0, 0, 0.498) 100%
        )
    `;
    }

    // --- Seek helper ---
    function seekToPercent(percent, snap = true) {
    const range = player.seekRange();
    let target = range.start + (percent / 100) * (range.end - range.start);

    if (snap) target = Math.round(target / segmentDur) * segmentDur;
    target = Math.min(Math.max(target, range.start), range.end - 0.1);
    video.currentTime = target;

    // Update fill immediately
    const playedPercent = ((target - range.start) / (range.end - range.start)) * 100;
    let bufferedEnd = 0;
    if (video.buffered.length > 0) bufferedEnd = video.buffered.end(video.buffered.length - 1);
    const bufferPercent = ((bufferedEnd - range.start) / (range.end - range.start)) * 100;

    seekbar.value = playedPercent;
    seekbar.style.background = `
        linear-gradient(
        to right,
        white 0%,
        white ${playedPercent}%,
        rgba(255,255,255,0.5) ${playedPercent}%,
        rgba(255,255,255,0.5) ${bufferPercent}%,
        rgba(0, 0, 0, 0.498) ${bufferPercent}%,
        rgba(0, 0, 0, 0.498) 100%
        )
    `;
    }

    // --- Input events ---
    seekbar.addEventListener("input", () => {
    if (!player.isLive()) return;
    isSeeking = true;
    seekToPercent(seekbar.value, false); // continuous follow
    });

    seekbar.addEventListener("change", () => {
    isSeeking = false;
    seekToPercent(seekbar.value, true); // snap on release
    if (thumbJumpTimer) clearInterval(thumbJumpTimer);
    thumbJumpTimer = setInterval(animateThumbSmooth, segmentDur * 1000);
    });

    // --- Scrubbing logic ---
    function startScrubbing(e) {
    if (!player.isLive()) return;
    isScrubbing = true;
    if (thumbJumpTimer) clearInterval(thumbJumpTimer);
    }

    function moveScrubbing(e) {
    if (!isScrubbing) return;
    const rect = seekbar.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    let percent = ((clientX - rect.left) / rect.width) * 100;
    percent = Math.max(0, Math.min(100, percent));
    seekbar.value = percent;
    seekToPercent(percent, false); // continuous follow red fill
    }

    function endScrubbing(e) {
    if (!isScrubbing) return;
    isScrubbing = false;
    isSeeking = false;
    seekToPercent(seekbar.value, true); // snap after release
    if (thumbJumpTimer) clearInterval(thumbJumpTimer);
    thumbJumpTimer = setInterval(animateThumbSmooth, segmentDur * 1000);
    }

    // Mouse
    seekbar.addEventListener("mousedown", startScrubbing);
    window.addEventListener("mousemove", moveScrubbing);
    window.addEventListener("mouseup", endScrubbing);

    // Touch
    seekbar.addEventListener("touchstart", startScrubbing);
    window.addEventListener("touchmove", moveScrubbing);
    window.addEventListener("touchend", endScrubbing);

    // --- Event listeners ---
    video.addEventListener("loadedmetadata", () => {
    detectSegmentDurationDynamic();
    updateLiveSeekbar();
    if (thumbJumpTimer) clearInterval(thumbJumpTimer);
    thumbJumpTimer = setInterval(animateThumbSmooth, segmentDur * 1000);
    });

    video.addEventListener("timeupdate", updateLiveSeekbar);
    video.addEventListener("progress", updateLiveSeekbar);
    player.addEventListener("manifestupdated", detectSegmentDurationDynamic);
    player.addEventListener("adaptation", detectSegmentDurationDynamic);

    // --- Cleanup ---
    window.addEventListener("beforeunload", () => {
    if (thumbJumpTimer) clearInterval(thumbJumpTimer);
    });



    // --- Resolution Dropdown ---
    // --- Helper to toggle disabled state ---
    const setResolutionBtnDisabled = (disabled) => {
        if (disabled) {
            resolutionBtn.classList.add('disabled');
            resolutionBtn.setAttribute('aria-disabled', 'true');
        } else {
            resolutionBtn.classList.remove('disabled');
            resolutionBtn.removeAttribute('aria-disabled');
        }
    };

    // --- Helper to toggle buttons when dropdown is open ---
    const toggleButtonsOnDropdown = () => {
        if (resolutionDropdown.classList.contains('show')) {
            centerPlayBtn.style.display = 'none';
            forwardBtn.style.display = 'none';
        } else {
            centerPlayBtn.style.display = 'block';
            forwardBtn.style.display = 'block';
        }
    };

    // --- Build resolution list ---
    const updateResolutionMenu = () => {
        resolutionDropdown.innerHTML = '';

        const tracks = (player.getVariantTracks() || []).sort((a, b) => b.height - a.height);

        if (!tracks.length) {
            setResolutionBtnDisabled(true);
            resolutionDropdown.classList.remove('show');
            toggleButtonsOnDropdown();
            return;
        }

        setResolutionBtnDisabled(false);

        // Auto option
        const autoOption = document.createElement('div');
        autoOption.textContent = 'Auto';
        if (player.getConfiguration().abr.enabled) autoOption.classList.add('selected');

        autoOption.onclick = (e) => {
            e.stopPropagation();
            if (!controlsLocked) {
                player.configure({ abr: { enabled: true } });
                resolutionDropdown.querySelectorAll('div').forEach(d => d.classList.remove('selected'));
                autoOption.classList.add('selected');
                resolutionDropdown.classList.remove('show');
                toggleButtonsOnDropdown();
            }
        };
        resolutionDropdown.appendChild(autoOption);

        // Quality list
        tracks.forEach((track) => {
            const item = document.createElement('div');
            item.textContent = `${track.height}p`;
            if (!player.getConfiguration().abr.enabled && track.active) item.classList.add('selected');

            item.onclick = (e) => {
                e.stopPropagation();
                if (!controlsLocked) {
                    player.configure({ abr: { enabled: false } });
                    player.selectVariantTrack(track, true);
                    resolutionDropdown.querySelectorAll('div').forEach(d => d.classList.remove('selected'));
                    item.classList.add('selected');
                    resolutionDropdown.classList.remove('show');
                    toggleButtonsOnDropdown();
                }
            };
            resolutionDropdown.appendChild(item);
        });
    };

    // --- Update when tracks become available ---
    player.addEventListener('adaptation', updateResolutionMenu);
    player.addEventListener('loaded', updateResolutionMenu);
    if (video) video.addEventListener('loadedmetadata', updateResolutionMenu);

    // --- Initial setup ---
    updateResolutionMenu();

    // --- Resolution button click ---
    resolutionBtn.onclick = (e) => {
        e.stopPropagation();
        if (controlsLocked) return;

        if (resolutionBtn.classList.contains('disabled')) {
            resolutionDropdown.classList.remove('show');
            toggleButtonsOnDropdown();
            return;
        }

        if (resolutionDropdown.children.length > 0) {
            resolutionDropdown.classList.toggle('show');
            toggleButtonsOnDropdown();
        } else {
            resolutionDropdown.classList.remove('show');
            toggleButtonsOnDropdown();
        }


        // Add red border on click
        resolutionBtn.style.border = "2px solid blue";

        // Optional: remove border after short delay
        setTimeout(() => {
            resolutionBtn.style.border = ""; // or "none"
        }, 200);
    };

    // --- Close dropdown on outside click ---
    document.addEventListener('click', () => {
        resolutionDropdown.classList.remove('show');
        toggleButtonsOnDropdown();
    });


    // --- Toggle Controls on Click Anywhere ---
    let controlsVisible = true;
    const setControlsVisibility = (visible) => {
        controlsVisible = visible;

        if (controlsLocked) {
            lockBtn.style.opacity = visible ? 0 : 1;
            controls.style.opacity = visible ? 0 : 1;
            lockBtn.style.pointerEvents = visible ? "none" : "auto";

            const otherControls = [topControls, backwardBtn, forwardBtn, centerPlayBtn, goLiveBtn, smallPlayBtn, muteBtn, volume, fullscreenBtn, resolutionBtn, closeBtn, seekbar];
            otherControls.forEach(el => {
                el.style.opacity = 0;
                el.style.pointerEvents = "none";
            });
            return;
        }

        const allControls = [topControls, backwardBtn, forwardBtn, controls, centerPlayBtn, goLiveBtn, smallPlayBtn, muteBtn, volume, fullscreenBtn, resolutionBtn, closeBtn, seekbar, lockBtn];
        allControls.forEach(el => {
            el.style.opacity = visible ? 0 : 1;
            el.style.pointerEvents = visible ? "none" : "auto";
        });
    };

    const toggleControls = () => {
        setControlsVisibility(!controlsVisible);
    };



/* ===============================
   BODY SCROLL CONTROL (Y ONLY)
================================ */

function lockBodyScrollY() {
    document.documentElement.style.overflowY = "hidden";
    document.body.style.overflowY = "hidden";
    document.body.style.touchAction = "none";
}

function unlockBodyScrollY() {
    document.documentElement.style.overflowY = "";
    document.body.style.overflowY = "";
    document.body.style.touchAction = "";
}


/* ===============================
   DRAGGABLE + PINCH PLAYER
================================ */

let isDragging = false;
let dragStartX = 0;
let dragStartY = 0;
let origX = 0;
let origY = 0;
let justDragged = false;
const DRAG_THRESHOLD = 5;

let gestureMode = null; // "drag" | "pinch"
let initialPinchDistance = null;
let initialContainerScale = 1;
let currentContainerScale = 1;
let hasDraggedOnceTouch = false;


/* ===============================
   LAST POSITION STORAGE
================================ */

let lastPlayerPos = { top: null, left: null, scale: 1 };

function applyLastPosition() {
    if (!lastPlayerPos.top || !lastPlayerPos.left) {
        playerContainer.style.top = "50%";
        playerContainer.style.left = "50%";
        playerContainer.style.transform = "translate(-50%, -50%) scale(1)";
        currentContainerScale = 1;
        hasDraggedOnceTouch = false;
    } else {
        playerContainer.style.top = lastPlayerPos.top;
        playerContainer.style.left = lastPlayerPos.left;
        playerContainer.style.transform = `translate(0, 0) scale(${lastPlayerPos.scale})`;
        currentContainerScale = lastPlayerPos.scale;
        hasDraggedOnceTouch = true;
    }
}

function updateLastPlayerPos() {
    lastPlayerPos.top = playerContainer.style.top;
    lastPlayerPos.left = playerContainer.style.left;
    const scaleMatch = playerContainer.style.transform.match(/scale\(([^)]+)\)/);
    lastPlayerPos.scale = scaleMatch ? parseFloat(scaleMatch[1]) : 1;
}


/* ===============================
   MOUSE DRAG (DESKTOP)
================================ */

playerContainer.addEventListener("mousedown", (e) => {
    if (document.fullscreenElement) return;
    if (e.target.closest("button") || e.target.closest("input")) return;

    isDragging = true;
    dragStartX = e.clientX;
    dragStartY = e.clientY;

    const rect = playerContainer.getBoundingClientRect();
    origX = rect.left;
    origY = rect.top;

    justDragged = false;
});

window.addEventListener("mousemove", (e) => {
    if (!isDragging) return;

    const deltaX = e.clientX - dragStartX;
    const deltaY = e.clientY - dragStartY;

    if (Math.abs(deltaX) > DRAG_THRESHOLD || Math.abs(deltaY) > DRAG_THRESHOLD) {
        justDragged = true;
    }

    playerContainer.style.left = origX + deltaX + "px";
    playerContainer.style.top = origY + deltaY + "px";
    playerContainer.style.transform = `translate(0, 0) scale(${currentContainerScale})`;
});

window.addEventListener("mouseup", () => {
    if (isDragging) updateLastPlayerPos();
    isDragging = false;
    setTimeout(() => justDragged = false, 50);
});


/* ===============================
   DESKTOP: CURSOR-FOCUSED ZOOM
================================ */

playerContainer.addEventListener("wheel", (e) => {
    if (document.fullscreenElement) return;
    if (isDragging) return; // 🚫 prevent drag conflict

    e.preventDefault();
    justDragged = true; // 🚫 prevent click toggle

    const rect = playerContainer.getBoundingClientRect();

    const offsetX = e.clientX - rect.left;
    const offsetY = e.clientY - rect.top;

    const zoomIntensity = 0.12;
    const prevScale = currentContainerScale;

    currentContainerScale += (e.deltaY < 0 ? zoomIntensity : -zoomIntensity);
    currentContainerScale = Math.min(Math.max(currentContainerScale, 0.7), 3);

    const scaleRatio = currentContainerScale / prevScale;

    const newLeft = rect.left - offsetX * (scaleRatio - 1);
    const newTop = rect.top - offsetY * (scaleRatio - 1);

    playerContainer.style.left = `${newLeft}px`;
    playerContainer.style.top = `${newTop}px`;
    playerContainer.style.transform = `translate(0, 0) scale(${currentContainerScale})`;
    playerContainer.style.transformOrigin = "top left";

    // 🔁 keep drag origin in sync
    origX = newLeft;
    origY = newTop;

    hasDraggedOnceTouch = true;
    updateLastPlayerPos();
}, { passive: false });


/* ===============================
   TOUCH: DRAG + PINCH
================================ */

playerContainer.addEventListener("touchstart", (e) => {
    if (document.fullscreenElement) return;
    if (e.target.closest("button") || e.target.closest("input")) return;

    if (e.touches.length === 1) {
        gestureMode = "drag";
        isDragging = true;

        const touch = e.touches[0];
        dragStartX = touch.clientX;
        dragStartY = touch.clientY;

        const rect = playerContainer.getBoundingClientRect();
        origX = rect.left;
        origY = rect.top;

        justDragged = false;
    }

    else if (e.touches.length === 2) {
        gestureMode = "pinch";
        lockBodyScrollY(); // 🔒 pinch locks immediately

        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        initialPinchDistance = Math.hypot(dx, dy);
        initialContainerScale = currentContainerScale;
    }
}, { passive: false });


window.addEventListener("touchmove", (e) => {

    /* ---- TOUCH DRAG ---- */
    if (gestureMode === "drag" && isDragging && e.touches.length === 1) {
        const touch = e.touches[0];
        const deltaX = touch.clientX - dragStartX;
        const deltaY = touch.clientY - dragStartY;

        if (
            !justDragged &&
            (Math.abs(deltaX) > DRAG_THRESHOLD || Math.abs(deltaY) > DRAG_THRESHOLD)
        ) {
            justDragged = true;
            hasDraggedOnceTouch = true;
            lockBodyScrollY(); // 🔒 lock Y only after drag starts
        }

        playerContainer.style.left = origX + deltaX + "px";
        playerContainer.style.top = origY + deltaY + "px";

        const translatePart = hasDraggedOnceTouch
            ? "translate(0, 0)"
            : "translate(-50%, -50%)";

        playerContainer.style.transform =
            `${translatePart} scale(${currentContainerScale})`;

        e.preventDefault();
    }

    /* ---- PINCH ---- */
    if (gestureMode === "pinch" && e.touches.length === 2 && initialPinchDistance) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const newDistance = Math.hypot(dx, dy);

        const scaleFactor = newDistance / initialPinchDistance;
        currentContainerScale = Math.min(
            Math.max(initialContainerScale * scaleFactor, 0.7),
            3
        );

        const translatePart = hasDraggedOnceTouch
            ? "translate(0, 0)"
            : "translate(-50%, -50%)";

        playerContainer.style.transform =
            `${translatePart} scale(${currentContainerScale})`;

        playerContainer.style.transformOrigin = "top left";
        e.preventDefault();
    }

}, { passive: false });


window.addEventListener("touchend", () => {
    if (gestureMode === "drag" || gestureMode === "pinch") {
        updateLastPlayerPos();
    }

    isDragging = false;
    initialPinchDistance = null;
    gestureMode = null;

    unlockBodyScrollY(); // 🔓 restore vertical scroll
    setTimeout(() => justDragged = false, 50);
});


/* ===============================
   CLICK TO TOGGLE CONTROLS
================================ */

playerContainer.addEventListener("click", (e) => {
    if (e.target.closest("button") || e.target.closest("input[type=range]")) return;
    if (justDragged) return;
    toggleControls();
});



    // Select the first element with class 'spinner'
    const spinner = document.querySelector('.spinner');

    // Show/hide functions
    function showSpinner() { 
        if (spinner) spinner.style.display = 'block'; 
    }
    function hideSpinner() { 
        if (spinner) spinner.style.display = 'none'; 
    }

    // Show spinner when buffering
    video.addEventListener('waiting', showSpinner);
    video.addEventListener('seeking', showSpinner);

    // Hide spinner when playback resumes
    video.addEventListener('playing', hideSpinner);
    video.addEventListener('seeked', hideSpinner);
    video.addEventListener('loadeddata', hideSpinner);

    // scrub forward/backward
    forwardBtn.addEventListener("click", () => {
    const range = player.seekRange();
    video.currentTime = Math.min(video.currentTime + 10, range.end);
    // Add red border on click
    forwardBtn.style.border = "2px solid blue";

    // Optional: remove border after short delay
    setTimeout(() => {
        forwardBtn.style.border = ""; // or "none"
    }, 200);
    });

    backwardBtn.addEventListener("click", () => {
    const range = player.seekRange();
    video.currentTime = Math.max(video.currentTime - 10, range.start);
    // Add red border on click
    backwardBtn.style.border = "2px solid blue";

    // Optional: remove border after short delay
    setTimeout(() => {
        backwardBtn.style.border = ""; // or "none"
    }, 200);
    });
};

let wakeLock = null;

async function requestWakeLock() {
  try {
    if ('wakeLock' in navigator) {
      wakeLock = await navigator.wakeLock.request('screen');
      console.log('🔋 Wake Lock active');

      wakeLock.addEventListener('release', () => {
        console.log('⚠️ Wake Lock was released');
        wakeLock = null;
      });

      wakeLock.onrelease = () => {
        console.log('⚠️ Wake Lock was released by system');
        wakeLock = null;
      };
    }
  } catch (err) {
    console.warn('Wake Lock request failed:', err);
  }
}

async function releaseWakeLock() {
  try {
    if (wakeLock) {
      await wakeLock.release();
      wakeLock = null;
      console.log('🔌 Wake Lock released');
    }
  } catch (err) {
    console.warn('Error releasing Wake Lock:', err);
  }
}
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    requestWakeLock(); // always try to reacquire
  }
});

