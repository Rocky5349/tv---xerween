from django.contrib import admin
from .models import (
    Category,
    Country,
    dash_player,
    proxy_player,
    channel,
    Event,
)

# =========================
# BASE ADMIN (loads admin.css)
# =========================
class BaseAdmin(admin.ModelAdmin):
    class Media:
        css = {
            "all": ("admin/admin.css",)
        }


# =========================
# CATEGORY
# =========================
@admin.register(Category)
class CategoryAdmin(BaseAdmin):
    list_display = ("name", "sport_type", "slug", "order")
    list_editable = ("order",)
    search_fields = ("name", "slug", "sport_type")
    list_filter = ("sport_type",)
    ordering = ("order", "name")
    prepopulated_fields = {}  # slug is MANUAL


# =========================
# COUNTRY
# =========================
@admin.register(Country)
class CountryAdmin(BaseAdmin):
    list_display = ("name",)
    search_fields = ("name",)


# =========================
# DASH PLAYER
# =========================
@admin.register(dash_player)
class DashPlayerAdmin(BaseAdmin):
    list_display = ("name", "title", "top_control_title")
    search_fields = ("name", "title")
    list_filter = ("name",)


# =========================
# PROXY PLAYER
# =========================
@admin.register(proxy_player)
class ProxyPlayerAdmin(BaseAdmin):
    list_display = ("name", "title", "top_control_title")
    search_fields = ("name", "title")


# =========================
# CHANNEL
# =========================
@admin.register(channel)
class ChannelAdmin(BaseAdmin):
    list_display = ("name", "order")
    list_editable = ("order",)
    search_fields = ("name",)
    ordering = ("order", "name")

    filter_horizontal = (
        "dash_players",
        "proxy_players",
        "categories",
        "countries",
    )


# =========================
# EVENT
# =========================
@admin.register(Event)
class EventAdmin(BaseAdmin):
    list_display = (
        "name",
        "match_label",
        "status",
        "start_time",
        "order",
    )
    list_editable = ("order",)
    list_filter = ("categories", "is_league_event", "start_time")
    search_fields = (
        "name",
        "team_a_name",
        "team_b_name",
        "match_label",
    )
    ordering = ("order", "start_time")
    readonly_fields = ("created_at",)

    filter_horizontal = (
        "dash_players",
        "proxy_players",
        "categories",
    )

    fieldsets = (
        ("Event Info", {
            "fields": ("name", "match_label", "is_league_event")
        }),
        ("Teams", {
            "fields": ("team_a_name", "team_b_name"),
        }),
        ("Images", {
            "fields": ("image_primary", "image_secondary"),
        }),
        ("Time", {
            "fields": ("start_time", "end_time"),
        }),
        ("Players & Categories", {
            "fields": ("dash_players", "proxy_players", "categories"),
        }),
        ("Ordering", {
            "fields": ("order",),
        }),
        ("System", {
            "fields": ("created_at",),
        }),
    )
